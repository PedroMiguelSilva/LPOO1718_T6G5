package dkeep.gui;
import javax.swing.JFrame;


public class Frame {
	public static void main(String args[]) {
		JFrame frame = new JFrame("Dungeon Keep");
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setSize(800,600);
		frame.setVisible(true);
	}

}
