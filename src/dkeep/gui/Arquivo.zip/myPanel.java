package dkeep.gui;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import dkeep.logic.Map;
///import dkeep.gui.Images;


import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;

import dkeep.logic.Coord;

import dkeep.logic.Game;

import dkeep.cli.Start;

public class myPanel extends JPanel{
	private Game game;
	Images images = new Images();

	public myPanel() {}


	public void setGame(Game game) {
		this.game = game;
	}
	
	//private Map map = game.getLevel().getMap();
	private BufferedImage wall = images.getWall();
	private BufferedImage hero = images.getHero();
	private BufferedImage armedH = images.getHero(); //preciso mudar isto!!!
	private BufferedImage guard = images.getGuard();
	private BufferedImage guardAsleep = images.getGuard();//isto tambem!!
	private BufferedImage ogre = images.getOgre();
	private BufferedImage stunedOgre = images.getOgre();//isto tambem
	private BufferedImage weapon = images.getWeapon();
	private BufferedImage door = images.getDoor();
	private BufferedImage lever = images.getLever();
	private BufferedImage key = images.getKey();
	

	public static BufferedImage scale(BufferedImage imageToScale, int dWidth, int dHeight) {
        BufferedImage scaledImage = null;
        if (imageToScale != null) {
            scaledImage = new BufferedImage(dWidth, dHeight, imageToScale.getType());
            Graphics2D graphics2D = scaledImage.createGraphics();
            graphics2D.drawImage(imageToScale, 0, 0, dWidth, dHeight, null);
            graphics2D.dispose();
        }
        return scaledImage;}
	

	public void drawGame(Graphics g, Map map, int elementWidth, int elementHeight, BufferedImage wall,
			BufferedImage hero, BufferedImage armedH,  BufferedImage guard, BufferedImage guardAsleep, BufferedImage key,
			BufferedImage ogre, BufferedImage stunedOgre, BufferedImage weapon, BufferedImage door, BufferedImage lever) {
		//map = this.map;
		wall = this.wall;
		hero = this.hero;
		armedH = this.armedH;
		guard = this.guard;
		guardAsleep = this.guardAsleep;
		ogre = this.ogre;
		stunedOgre = this.ogre;
		weapon = this.weapon;
		door = this.door;
		lever = this.lever;
		key = this.key;


		for (int i = 0; i < game.getLevel().getMap().getHeight(); i++) {
			for (int j = 0; j < game.getLevel().getMap().getWidth(); j++) {
				int x = j * elementWidth;
				int y = i * elementHeight;
				Coord coord = new Coord(i,j);
				char sym = Start.symbolToChar(map.getEnt(coord).getSymb());
				switch(sym) {
				case 'X': g.drawImage(wall, x, y, this); break;
				case 'I': g.drawImage(door, x, y, this); break;
				case 'k': g.drawImage(lever, x, y, this); break;
				case 'h': g.drawImage(hero, x, y, this); break;
				case 'K': g.drawImage(armedH, x, y, this); break; //with key
				case 'G': g.drawImage(guardAsleep, x, y, this); break;
				case 'g': g.drawImage(guard, x, y, this); break; //asleep
				case 'O': g.drawImage(ogre, x, y, this); break;
				case '8': g.drawImage(stunedOgre, x, y, this); break; //stunned
				case '*': g.drawImage(weapon, x, y, this); break;
				case '$': g.drawImage(key, x, y, this); break;
				default: break;
				}
			}
		}
	}

	public void paintComponent(Graphics g){
		super.paintComponent(g);
		int elementWidth = this.getWidth() / game.getLevel().getMap().getWidth();
		int elementHeight = this.getHeight() /game.getLevel().getMap().getHeight();
		BufferedImage Wall = scale(wall, elementWidth, elementHeight);
		BufferedImage Door = scale(door, elementWidth, elementHeight);
		BufferedImage Lever = scale(lever, elementWidth, elementHeight);
		BufferedImage Hero = scale(hero, elementWidth, elementHeight);
		BufferedImage ArmedH = scale(armedH, elementWidth, elementHeight);
		BufferedImage Guard = scale(guard, elementWidth, elementHeight);
		BufferedImage GuardAsleep = scale(guardAsleep, elementWidth, elementHeight);
		BufferedImage Ogre = scale(ogre, elementWidth, elementHeight);
		BufferedImage StunedOgre = scale(ogre, elementWidth, elementHeight); //atenção!!
		BufferedImage Weapon = scale(weapon, elementWidth, elementHeight);
		BufferedImage Key = scale(key, elementWidth, elementHeight);
		
		drawGame(g,game.getLevel().getMap(),elementWidth,elementHeight, Wall,Hero,ArmedH,Guard, GuardAsleep,Key,
				 Ogre,StunedOgre,Weapon,Door,Lever);
	
	
	}
	
}