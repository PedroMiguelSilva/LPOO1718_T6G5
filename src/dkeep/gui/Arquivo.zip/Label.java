package dkeep.gui;
import javax.swing.*;


public class Label {
	JLabel frame = new JLabel ("Dungeon Keep");

}
